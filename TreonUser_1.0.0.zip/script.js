document.addEventListener('DOMContentLoaded', () => {
  const video = document.getElementById('video');
  if (video && navigator.mediaDevices?.getUserMedia) {
    navigator.mediaDevices.getUserMedia({ video: true }).then(stream => {
      video.srcObject = stream;
    }).catch(() => {
      alert('Camera not available');
    });
  }

  enableManualInfiniteScroll('.brand-scroll');
  enableManualInfiniteScroll('.color-scroll');
});

function enableManualInfiniteScroll(containerSelector) {
  const container = document.querySelector(containerSelector);
  if (!container) return;

  const row = container.querySelector('.scroll-row');
  if (!row) return;

  // Triple the content to make room for looping
  row.innerHTML = row.innerHTML + row.innerHTML + row.innerHTML;

  const totalWidth = row.scrollWidth;
  const third = totalWidth / 3;

  container.scrollLeft = third;

  // Loop scroll behavior
  container.addEventListener('scroll', () => {
    if (container.scrollLeft <= 0) {
      container.scrollLeft = third;
    } else if (container.scrollLeft >= totalWidth - container.clientWidth) {
      container.scrollLeft = third - container.clientWidth;
    }
  });

  // Make vertical mouse wheel scroll horizontally
  container.addEventListener('wheel', (e) => {
    e.preventDefault();
    container.scrollLeft += e.deltaY;
  }, { passive: false });
}

document.addEventListener('DOMContentLoaded', () => {
  const doneButton = document.querySelector('.done-button');
  const modal = document.getElementById('confirmModal');
  const yesBtn = document.getElementById('confirmYes');
  const cancelBtn = document.getElementById('confirmCancel');

  if (doneButton && modal && yesBtn && cancelBtn) {
    doneButton.addEventListener('click', () => {
      modal.classList.remove('hidden');
    });

    yesBtn.addEventListener('click', () => {
      window.location.href = 'privacy.html';
    });

    cancelBtn.addEventListener('click', () => {
      modal.classList.add('hidden');
    });
  }
});
